let EMediaCategory = {
    prizeDesktop: "prizeDesktop",
    prizeMobile: "prizeMobile",
    productDesktop: "productDesktop",
    productMobile: "productMobile",
    uspSmallDesktop: "uspSmallDesktop",
    uspSmallMobile: "uspSmallMobile",
    uspDesktop: "uspDesktop",
    uspMobile: "uspMobile",
    galleryDesktop: "galleryDesktop",
    galleryMobile: "galleryMobile"
}

export const constantSrv = {
    EMediaCategory
}