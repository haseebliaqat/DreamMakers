import React, { useState, useEffect } from 'react';
import './payment.less';

function Payment() {
    return (
        <div></div>
    );
}

export default Payment;