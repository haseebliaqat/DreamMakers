import React, { useState, useEffect } from 'react';
import './information.less';

function Information() {
    return (
        <div></div>
    );
}

export default Information;