import React, { useState, useEffect } from 'react';
import './confirmation.less';

function Confirmation() {
    return (
        <div></div>
    );
}

export default Confirmation;