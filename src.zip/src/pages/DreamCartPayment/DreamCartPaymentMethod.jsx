import React, { useState, useEffect } from 'react';
import './DreamCartPaymentMethod.css';
import Card from '@/_shared/dreamCart/Card';
import { TextField } from '@/_shared/TextField/TextField';
import { SelectField } from '@/_shared/SelectField/SelectField';
import CheckoutBtns from '@/_shared/dreamCart/CheckoutBtns';
import DreamCartSteper from '@/_shared/dreamCart/DreamCartSteper';
import { NewsLetter } from '@/_shared/newsletter/newsletter';
import { CountryCodeField } from '@/_shared/CountryCodeField/CountryCodeField';
import OrderSummery from '@/_shared/dreamCart/OrderSummery';
import GoogleIcon from '@/_assets/icons/google-sm.png';
import FacebookIcon from '@/_assets/icons/facebook-sm.png';
import AppleIcon from '@/_assets/icons/apple-sm.png';
import { Link } from 'react-router-dom';
import StripeCheckout from 'react-stripe-checkout';
import Stripe from '@/_assets/dreamCart/stripe-payment-logo.png';
import Logo from '@/_assets/icons/apple-sm.png';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogTitle from '@material-ui/core/DialogTitle';
import DialogContentText from '@material-ui/core/DialogContentText';
import Dialog from '@material-ui/core/Dialog';
import AppleStore from '@/_assets/dreamCart/AppleStore.png';
import GooglePlay from '@/_assets/dreamCart/GooglePlay.png';
import CreditCard from '@/_assets/dreamCart/CreditCard.png';
import CheckoutBilling from '@/_assets/dreamCart/CheckoutBilling.svg';
import { useHistory } from "react-router-dom";
import { accountService, alertService } from '@/_services';
// import CheckoutForm from "./DreamCartCheckoutPaymentForm";
import CheckoutForm from "./DreamCartCheckoutPaymentForm";
import DatePicker from "react-datepicker";
import InputMask from "react-input-mask";
import GooglePayButton from '@google-pay/button-react';
// import {
//   CardElement,
//   Elements,
//   useElements,
//   useStripe
// } from "@stripe/react-stripe-js";
 import { loadStripe } from "@stripe/stripe-js";
 import { Elements } from "@stripe/react-stripe-js";
 const CARD_ELEMENT_OPTIONS = {
   style: {
     base: {
       lineHeight: "27px",
       color: "#212529",
       fontSize: "1.1rem",
       "::placeholder": {
         color: "#494949",
       },
     },
     invalid: {
       color: "#494949",
       iconColor: "#494949",
     },
   },
 };
 const stripePromise = loadStripe("pk_test_51J9sJcLWHAHcBPawYJoIvw6bio18W18BpYMKJTupgMkfb5UvZwHdD3YIdoR6moN5QVIX8xW3vRxItrFYpilVorqz00dObeqilS");
//const stripePromise = loadStripe("pk_test_51J9sJcLWHAHcBPawYJoIvw6bio18W18BpYMKJTupgMkfb5UvZwHdD3YIdoR6moN5QVIX8xW3vRxItrFYpilVorqz00dObeqilS");
// const CheckoutForm = () => {
//    const options = {
//       style: {
//         base: {
//           color: "#32325d",
//           fontFamily: '"Helvetica Neue", Helvetica, sans-serif',
//           fontSmoothing: "antialiased",
//           fontSize: "16px",
//           "::placeholder": {
//             color: "#aab7c4"
//           }
//         },
//         invalid: {
//           color: "#fa755a",
//           iconColor: "#fa755a"
//         }
//       }
//     };
//    const [clientSecret, setClientSecret] = useState(null);
//   const [error, setError] = useState(null);
//   const [metadata, setMetadata] = useState(null);
//   const [succeeded, setSucceeded] = useState(false);
//   const [processing, setProcessing] = useState(false);
//   const stripe = useStripe();
//   const elements = useElements();
//   const [firstname, setfirstname] = useState(localStorage.getItem("f_name")+" "+localStorage.getItem("l_name"));
//   const [email, setemail] = useState(localStorage.getItem("user_email"));
 

//   const handleSubmit =  ev => {
//    ev.preventDefault();
//    if(firstname!=""){
//       setProcessing(false);
//       const payload =  stripe.confirmCardPayment(clientSecret, {
//         payment_method: {
//           card: elements.getElement(CardElement),
//           billing_details: {
//             name: firstname
//           }
//         }
//       });
//    }else{
//       alert("Please Provide Card Holder Name")
//    }

//    if (payload.error) {
//      setError(`Payment failed: ${payload.error.message}`);
//      setProcessing(false);
//      console.log("[error]", payload.error);
//    } else {
//      setError(null);
//      setSucceeded(true);
//      setProcessing(false);
//      setMetadata(payload.paymentIntent);
//      console.log("[PaymentIntent]", payload.paymentIntent);
//    }
//  };
//  const Fname = (event) => {
//    console.log(event);
//    setfirstname(event.target.value)
// }
//    return (
//      <div id="card-element">
//        <h4 className="d-flex justify-content-between align-items-center mb-3">
//          <span className="text-muted">Payment Method</span>
//        </h4>
//        <form onSubmit={handleSubmit}>
  
//          <div className="row">
//            <div className="col-md-6 mb-3">
//              <label htmlFor="cc-name">Cardholder name*</label>
//              <TextField
//                className="form-control sr-input"
//                type="text"
//                id="name"
//                name="name"
//                autoComplete="cardholder"
//                // disabled={true}
//                onChange={Fname}
//                value={firstname}
//              />
//            </div>
//            <div className="col-md-6 mb-3">
//              <label htmlFor="cc-email">Email</label>
//              <TextField
//                className="form-control sr-input"
//                type="text"
//                id="name"
//                name="name"
//                autoComplete="cardholder"
//                // disabled={true}
//                value={email}
//              />
//            </div>
//          </div>
  
//          <div className="sr-combo-inputs-row">
//             <CardElement
//               className="sr-input sr-card-element"
//               options={options}
//             />
//           </div>
  
         
//           {error && <div className="message sr-field-error">{error}</div>}
//          <hr className="mb-4" />
//             <button className={`btn form-control my-1 buttonRound`} style={{border:"1px solid",width:"465px",backgroundColor:"rgb(22, 99, 190)",color:"aliceblue"}}
//            disabled={processing  || !stripe}
//           type="submit">
//               {processing ? "Processing…" : "Pay"}
//          </button>
//          {/* {errorMsg && <div className="text-danger mt-2">{errorMsg}</div>} */}
//        </form>
//      </div>
//    );
//  };

//  const InjectedCheckoutForm = () => (
//    <ElementsConsumer>
//      {({stripe, elements}) => (
//        <CheckoutForm stripe={stripe} elements={elements} />
//      )}
//    </ElementsConsumer>
//  );
// const ELEMENTS_OPTIONS = {
//    fonts: [
//      {
//        cssSrc: "https://fonts.googleapis.com/css?family=Roboto"
//      }
//    ]
//  };
import config from 'config';
const baseUrl = `${config.apiUrl}`;
import { fetchWrapper, history } from '@/_helpers';
const DreamCartPaymentMethod = () => {
    const history = useHistory();
   const [imageShow, setImageShow] = useState(false);
   const [TermAndCondition, setTermsandcondition] = useState(!!localStorage.getItem("user_id")?true:false);
   const [AlreadyLogin, setAlreadyLogin] = useState(!!localStorage.getItem("user_id")?true:false);
   const [firstname, setfirstname] = useState(localStorage.getItem("f_name"));
   const [last_name, setlast_name] = useState(localStorage.getItem("l_name"));
   const [email, setemail] = useState(localStorage.getItem("user_email"));
   const [nationality, setnationality] = useState("");
   const [city, setcity] = useState("");
   const [phone_no, setphone_no] = useState("");
   const [invite_code, setsetinvite_code] = useState("");
   const [gender_value_male, setGenderValueMale] = useState(false);
   const [gender_value_female, setGenderValueFemale] = useState(false);
   const [campain_actual_price, setCampainActualPrice] = useState(localStorage.getItem("selected_campaign_actual_price"));
   const [campain_cash_paid, setCampainCashPaid] = useState(localStorage.getItem("selected_campaign_cash_paid"));
   const [campain_id, setCampainID] = useState(localStorage.getItem("selected_campaign_id"));
   const [campain_discount, setCampainDiscount] = useState(localStorage.getItem("discount_code"));
   const [campain_dreamcoin, setCampainDreamCoin] = useState(localStorage.getItem("dream_coins"));
   const [campain_count, setCampainCount] = useState(localStorage.getItem("item_count_value"));
   const [discount_amount, setDiscountAmount] = useState(localStorage.getItem("selected_campaign_discount_amount"));
   const [user, setUser] = useState(null);
   const [card_number, setCardNumber] = useState([null]);
   const [expiry_date, setExpriyDate] = useState([null]);
   const [cvc_number, setCVCNumber] = useState([null]);
   const now = new Date;
  const until = new Date(now.getFullYear() + 10, now.getMonth());
  const [clientSecret, setClientSecret] = useState("");
   useEffect(() => {
          if (!!localStorage.userDetails) {            
            setUser(JSON.parse(localStorage.userDetails));
            //console.log(user);
        }
      //   let url ='https://api.dreammakers.ae:4000/coupons/create-payment-intent'
      //  fetch(url, {
      //       method: "POST",
      //       body: JSON.stringify({ "campaignId": parseInt(campain_id),numberOfCouponsToPurchase:parseInt(campain_count) }),
      //     })
      //   .then((res) => { 
      //     return res.json();
      //   }).then((data) => {
      //     setClientSecret(data.clientSecret);
      //   });
       const PaymentIntentURL=`${baseUrl}/coupons/create-payment-intent`;
        fetchWrapper.post(PaymentIntentURL, { "campaignId": parseInt(campain_id),numberOfCouponsToPurchase:parseInt(campain_count) }).then((resp) => {
            console.log("payment-intent", resp);

            setClientSecret(resp.client_secret);

        })
            .catch(error => {
                alertService.error(error);
            });
          window.scrollTo(0, 0)
    // googlePayClient
    // .isReadyToPay(googlePayBaseConfiguration)
    // .then(res => {
    //   if (res.result) {
    //     createAndRenderPayButton();
    //   } else {
    //     alert("Unable to pay using Google Pay");
    //   }
    // })
    // .catch(function (err) {
    //   console.error("Error determining readiness to use Google Pay: ", err);
    // });
      if (window.innerWidth < 576) setImageShow(true);
      window.addEventListener('resize', () => {
         if (window.innerWidth < 576) setImageShow(true);
         else setImageShow(false);
      });
      return window.removeEventListener('resize', () => {});
   }, []);

   function GetClientScreat(email, password) {
    return fetchWrapper.post(`${baseUrl}/coupons/create-payment-intent`, { email, password })
        .then(user => {
            // publish user to subscribers and start timer to refresh token
            userSubject.next(user);
            startRefreshTokenTimer();
            return user;
        });
}
   //---------------Gpay---------------------
   const { googlePayClient } = window;
   const baseCardPaymentMethod = {
      amount: 999,
      type: "CARD",
      parameters: {
        allowedAuthMethods: ["PAN_ONLY", "CRYPTOGRAM_3DS"],
        allowedCardNetworks: ["MASTERCARD", "VISA"]
      }
    };
    const googlePayBaseConfiguration = {
      apiVersion: 2,
      apiVersionMinor: 0,
      allowedPaymentMethods: [baseCardPaymentMethod]
    };
    const processPayment=()=> {

        console.log("test");
        const tokenizationSpecification = {
          type: "PAYMENT_GATEWAY",
          parameters: {
            gateway: "stripe",
            "stripe:version": "v3",
            "stripe:publishableKey": "pk_test_35p114pH8oNuHX72SmrvsFqh00Azv3ZaIA"
          }
        };
        const cardPaymentMethod = {
          type: "CARD",
          tokenizationSpecification: tokenizationSpecification,
          parameters: {
            allowedAuthMethods: ["PAN_ONLY", "CRYPTOGRAM_3DS"],
            allowedCardNetworks: ["MASTERCARD", "VISA"],
            billingAddressRequired: false,
            // billingAddressParameters: {
            //   format: "FULL",
            //   phoneNumberRequired: true
            // }
          }
        };
     
        const transactionInfo = {
          totalPriceStatus: "FINAL",
          totalPrice: !!campain_price?campain_price:"",
          currencyCode: "USD",
          countryCode: "US"
        };
     
        const merchantInfo = {
          // merchantId: '01234567890123456789', Only in PRODUCTION
          merchantName: "Example Merchant Name"
        };
     
        const paymentDataRequest = {
          ...googlePayBaseConfiguration,
          ...{
            allowedPaymentMethods: [cardPaymentMethod],
            transactionInfo,
            merchantInfo
          }
        };
     
        googlePayClient
          .loadPaymentData(paymentDataRequest)
          .then(function (paymentData) {
            console.log(paymentData);
          })
          .catch(function (err) {
            console.log(err);
          });
      }
     

// const processPaymentStrip = (token, addresses) => {
//    console.log("token " +JSON.stringify(token))
//    console.log(token.id)
//   const userDetails = { discountCode:campain_discount, campaignId:campain_id,actualPrice:campain_actual_price, discountAmount:campain_price,
//   dreamCoinsUsed:"0", cashPaid:campain_price,totalPurchasedCoupons:campain_count, payment_token_id:token.id,
//   type_of_payment:"stripe", payemnt_instrument:"card",payemnt_instrument_type:"VISA",
// }
//   console.log(userDetails);
//   alertService.clear();
//   accountService.PurchaseCoupons(userDetails.discountCode,
//    userDetails.campaignId,
//    userDetails.actualPrice,
//    userDetails.discountAmount,
//    userDetails.dreamCoinsUsed,
//    userDetails.cashPaid,
//    userDetails.totalPurchasedCoupons,
//    userDetails.payment_token_id,
//    userDetails.type_of_payment,
//    userDetails.payemnt_instrument,
//    userDetails.payemnt_instrument_type,
//    ).then((resp) => {
//      console.log(resp)
//      localStorage.setItem("purchase_detail",JSON.stringify(resp));
//          if(addresses!="" ||token){
//      const { from } = location.state || { from: { pathname: "/confirmation" } };
//      history.push(from);
//  }

//   }).catch(error => {
//       alertService.error("Internal Server Error");
//   });
// };
   
const CardNumber = (event) => {
  console.log(event);
  
  setCardNumber(event.target.value)
}

const ExpireyDate = (event) => {
  console.log(event);
  setExpriyDate(event.target.value)
}
const CVCNumber = (event) => {
  console.log(event);
  setCVCNumber(event.target.value)
}
const appearance = {
  theme: 'stripe',
};
const options = {
  clientSecret,
  appearance,
};

const [stepNo, setstepNo] = useState(3);
return (
   <>
      <DreamCartSteper value={stepNo} />
         <div className="container-fluid">
            <div className="row">
               <div className="col-12 p-0">
                  {/* <OrderSummery /> */}
               </div>
               <div className="col-md-12 col-lg-5 py-md-5 py-3 px-md-3 px-1">
                  <div className="container px-md-5 px-4">
                  <div className="row s-box">
      
                           <div className="col-md-12 order-md-1">
                           {clientSecret && (
                                <Elements options={options} stripe={stripePromise}>
                                  <CheckoutForm />
                                </Elements>
                            )}
                           </div>
                           {/* <div className="col-md-12">
                           <InputMask
                            mask="9999 9999 9999 9999"
                            onChange={CardNumber}
                            value={card_number}
                              maskChar=""
                            >
                              {() =>
                                <TextField label="Card Number*"/>
                              }</InputMask>

                        </div>
                        <div className="col-md-12">
                                      <InputMask
                            mask="99/99"
                            onChange={ExpireyDate}
                            value={expiry_date}
                              maskChar=""
                            >
                              {() =>
                                <TextField label="Expire Date*" />
                              }</InputMask>

                           
                        </div>
                        <div className="col-md-12">
                        <InputMask
                            mask="999"
                            onChange={CVCNumber}
                            value={cvc_number}
                              maskChar=""
                            >
                              {() =>
                                <TextField label="CVC*"/>
                              }</InputMask>
                           
                        </div>
                        <div className="col-md-12">
                           <div className="mt-5">
                          
                           <button className={`btn form-control my-1 buttonRound`} style={{border:"1px solid",width:"465px",backgroundColor:"rgb(22, 99, 190)",color:"aliceblue"}}  onClick={LoginGuest}>
                                 <span className="FloarRight-Responsive">Pay</span>
                                 </button>
                           </div>
                        </div> */}
                      </div>
                     <div className="row" style={{marginTop:"17PX"}}>
                        <div className="col-md-12">
                           {/* <div className="mt-5">
                                 <button className={`btn form-control my-1 buttonRound`} style={{border:"1px solid",width:"465px",backgroundColor:"rgb(22, 99, 190)",color:"aliceblue"}}>
                                 <img
                                    src={imageShow ? CheckoutBilling : CreditCard}
                                    alt=""
                                    height={30}
                                    className="absoluteClass U-paddingLeftText"
                                    style={{paddingLeft:"35px"}}
                                 />
                                 <span className="FloarRight-Responsive">Pay</span>
                                 </button>
                           </div> */}
                           {/* <button className={`btn form-control my-1 buttonRound`} style={{border:"1px solid",width:"465px" ,backgroundColor:"black"}}  onClick={processPayment}>
                                    <img
                                        src={GooglePlay}
                                        alt=""
                                        height={24}
                                        className="absoluteClass U-paddingLeftText"
                                        style={{paddingLeft:"35px"}}
                                    />
                                    <span className="FloarRight-Responsive" style={{color:"white",fontWeight:"400"}}>Google Pay</span>
                            </button> */}
                                        <GooglePayButton
            buttonSizeMode="fill"
            
        style={{ width: 465, height: 43 }}
            environment="TEST"
            paymentRequest={{
              apiVersion: 2,
              apiVersionMinor: 0,
                allowedPaymentMethods: [
                  {
                    type: 'CARD',
                    parameters: {
                      allowedCardNetworks: ["VISA", "MASTERCARD"],
                      allowedAuthMethods: ["PAN_ONLY", "CRYPTOGRAM_3DS"],
                    },
                    tokenizationSpecification: {
                      type: 'PAYMENT_GATEWAY',
                      parameters: {
                        gateway: "stripe",
                        "stripe:version": "v3",
                        "stripe:publishableKey": "pk_test_51J9sJcLWHAHcBPawYJoIvw6bio18W18BpYMKJTupgMkfb5UvZwHdD3YIdoR6moN5QVIX8xW3vRxItrFYpilVorqz00dObeqilS"
                      }
                    },
                  },
                ],
                merchantInfo: {
                  merchantId: 'BCR2DN6TQ7AOBHRW',
                  merchantName: 'Dream Makers',
                },
                transactionInfo: {
                  totalPriceStatus: 'FINAL',
                  totalPriceLabel: 'Total',
                  totalPrice: '100.00',
                  currencyCode: 'USD',
                  countryCode: 'US',
                },
              }}

              onLoadPaymentData={paymentRequest => {
                console.log('load payment data', paymentRequest);
                const PaymentIntentURL=`${baseUrl}/coupons/create-payment-intent`;
                fetchWrapper.post(PaymentIntentURL, { "campaignId": parseInt(campain_id),numberOfCouponsToPurchase:parseInt(campain_count) }).then((resp) => {
                    console.log("payment-intent", resp);
        
                    setClientSecret(resp.client_secret);
        
                })
                    .catch(error => {
                        alertService.error(error);
                    });
              }}
          
/>
                            <button className={`btn form-control my-1 buttonRound`} style={{border:"1px solid",width:"465px"}}>
                                <img
                                        src={AppleStore}
                                        alt=""
                                        height={24}
                                        className="absoluteClass U-paddingLeftText"
                                        style={{paddingLeft:"35px"}}
                                    />
                                <span className="FloarRight-Responsive">Apple pay</span>
                            </button>
                        </div>
                     </div>
                  </div>
               </div>

               {/* <div className="col-md-12 col-lg-5 py-md-5 py-3 px-md-3 px-1">
                  <div className="container px-md-5 px-4">
                     <div className="row">
                     <div >

                           
            <StripeCheckout
                                            label="Strip"
                                            amount={!!campain_price?" "+campain_price:""}
                                            //   description="Awesome Product"
                                            //   image={Logo}
                                            locale="auto"
                                            name="https://dreammakers.ae/"
                                            stripeKey="pk_test_35p114pH8oNuHX72SmrvsFqh00Azv3ZaIA"
                                            token={onStripToken}
                                            className={`btn form-control my-1 buttonRound`} 
                                            style={{border:"1px solid",backgroundColor:"none"}}
                                            currency="AED"
                                            email={!!user?user.email:""}
                                            zipCode={false}
              >
                <button className={`btn form-control my-1 buttonRound`} style={{border:"1px solid",width:"465px"}}>
                <img
                    src={Stripe}
                    alt=""
                    height={30}
                    className="absoluteClass U-paddingLeftText"
                    style={{paddingLeft:"35px"}}
                />
                <span className="FloarRight-Responsive">Stripe</span>
                </button>
                  </StripeCheckout>
                
             </div>
                        
                        
                        
                     </div>
                  </div>
               </div> */}
               
               <div className="col-md-12 col-lg-7 cardNoShowLess768">
                  <Card />
               </div>
               <div className="col-12">
                  <NewsLetter />
               </div>
            </div>
         </div>
      </>
   );
};

export default DreamCartPaymentMethod;
