import React, { useState, useEffect } from 'react';
import {
   Button,
 } from "@material-ui/core";
import CheckoutBtns from '@/_shared/dreamCart/CheckoutBtns';
import AppleStore from '@/_assets/dreamCart/AppleStore.png';
import GooglePlay from '@/_assets/dreamCart/GooglePlay.png';
import CreditCard from '@/_assets/dreamCart/CreditCard.png';
import CheckoutBilling from '@/_assets/dreamCart/CheckoutBilling.svg';
import Stripe from '@/_assets/dreamCart/stripe-payment-logo.png';
import { Elements } from '@stripe/react-stripe-js';
import {loadStripe} from '@stripe/stripe-js';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogTitle from '@material-ui/core/DialogTitle';
import DialogContentText from '@material-ui/core/DialogContentText';
import Dialog from '@material-ui/core/Dialog';
import {PaymentElement} from '@stripe/react-stripe-js';
import StripeCheckout from 'react-stripe-checkout';
import { Link } from 'react-router-dom';
import GooglePayButton from '@google-pay/button-react';
import {
  useStripe, useElements,
  CardNumberElement, CardExpiryElement, CardCvcElement
} from '@stripe/react-stripe-js'
import { useHistory } from "react-router-dom";
import "./CardBottom.css";
const stripePromise = loadStripe("pk_live_51J9sJcLWHAHcBPawsL2TFamufBJD1NwYndmchPlFvKlu7hbYskZnxVIgtiIiQJem38YvRF9iWCSKDV8xvkVMOZeo0044uh9fuE");
const CARD_ELEMENT_OPTIONS = {
   style: {
     base: {
       lineHeight: "27px",
       color: "#212529",
       fontSize: "1.1rem",
       "::placeholder": {
         color: "#aab7c4",
       },
     },
     invalid: {
       color: "#fa755a",
       iconColor: "#fa755a",
     },
   },
 };
 const successMessage = () => {
   return (
     <div className="success-msg">
       <svg width="1em" height="1em" viewBox="0 0 16 16" className="bi bi-check2" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
         <path fill-rule="evenodd" d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z" />
       </svg>
       <div className="title">Payment Successful</div>
     </div>
   )
 }

 const CheckoutForm = () => {
   const stripe = useStripe();
   const elements = useElements();
 
   const handleSubmit = (event) => {
     event.preventDefault();
 
     if (elements == null) {
       return;
     }
 
     const {error, paymentMethod} = stripe.createPaymentMethod({
       type: 'card',
       card: elements.getElement(CardElement),
     });
   };
   return (
     <div>
       <h4 className="d-flex justify-content-between align-items-center mb-3">
         <span className="text-muted">Payment Method</span>
       </h4>
       <form onSubmit={handleSubmit}>
  
         <div className="row">
           <div className="col-md-6 mb-3">
             <label htmlFor="cc-name">Cardholder name*</label>
             <input
               id="cc-name"
               type="text"
               className="form-control"
               // value={name}
               onChange={e => setName(e.target.value)}
             />
           </div>
           <div className="col-md-6 mb-3">
             <label htmlFor="cc-email">Email</label>
             <input
               id="cc-email"
               type="text"
               className="form-control"
               // value={email}
               onChange={e => setEmail(e.target.value)}
             />
           </div>
         </div>
  
         <div className="row">
           <div className="col-md-12 mb-3">
             <label htmlFor="cc-number">Card Number*</label>
             <CardNumberElement
               id="cc-number"
               className="form-control"
               options={CARD_ELEMENT_OPTIONS}
             />
           </div>
         </div>
  
         <div className="row">
           <div className="col-md-6 mb-3">
             <label htmlFor="expiry">Expiration Date*</label>
             <CardExpiryElement
               id="expiry"
               className="form-control"
               options={CARD_ELEMENT_OPTIONS}
             />
           </div>
           <div className="col-md-6 mb-3">
             <label htmlFor="cvc">CVC*</label>
             <CardCvcElement
               id="cvc"
               className="form-control"
               options={CARD_ELEMENT_OPTIONS}
             />
           </div>
         </div>
  
         <hr className="mb-4" />
         {/* <button className="btn btn-dark w-100" type="submit">
           {loading ? <div className="spinner-border spinner-border-sm text-light" role="status"></div> : `PAY ₹${props.amount}`}
         </button>
         {errorMsg && <div className="text-danger mt-2">{errorMsg}</div>} */}
       </form>
     </div>
   );
 };
// ----------Google Pay-------------------
const { googlePayClient } = window;
const baseCardPaymentMethod = {
   type: "CARD",
   parameters: {
     allowedCardNetworks: ["VISA", "MASTERCARD"],
     allowedAuthMethods: ["PAN_ONLY", "CRYPTOGRAM_3DS"]
   }
 };
 const googlePayBaseConfiguration = {
   apiVersion: 2,
   apiVersionMinor: 0,
   allowedPaymentMethods: [baseCardPaymentMethod]
 };
 
const CardBottom = ({ checkoutAsGuest,props,stepNo,setstepNo}) => {
   const [HideCheckout, setHideCheckout] = useState(true);
   const [imageShow, setImageShow] = useState(false);
   const [gPayBtn, setGPayBtn] = useState(null);
   const [open, setOpen] = React.useState(false);
   const [paymentCompleted, setPaymentCompleted] = useState(false);
   const [user, setUser] = useState(null);
   const [RegisterUser, setResisterUser] = useState(localStorage.getItem("user_id"));
   const onToken = (token, addresses) => {
     console.log("token " +JSON.stringify(token))
     console.log("addresses " +JSON.stringify(addresses))
  };

  const history = useHistory();
  const processPayment=()=> {
   console.log("test");
   const tokenizationSpecification = {
     type: "PAYMENT_GATEWAY",
     parameters: {
       gateway: "stripe",
       "stripe:version": "v3",
       "stripe:publishableKey": "pk_test_35p114pH8oNuHX72SmrvsFqh00Azv3ZaIA"
     }
   };
   const cardPaymentMethod = {
     type: "CARD",
     tokenizationSpecification: tokenizationSpecification,
     parameters: {
       allowedCardNetworks: ["VISA", "MASTERCARD"],
       allowedAuthMethods: ["PAN_ONLY", "CRYPTOGRAM_3DS"],
       billingAddressRequired: false,
       billingAddressParameters: {
         format: "FULL",
         phoneNumberRequired: true
       }
     }
   };

   const transactionInfo = {
     totalPriceStatus: "FINAL",
     totalPrice: "123.45",
     currencyCode: "USD"
   };

   const merchantInfo = {
     merchantId: 'BCR2DN6TQ7AOBHRW',
     merchantName: "Dream Makers"
   };

   const paymentDataRequest = {
     ...googlePayBaseConfiguration,
     ...{
       allowedPaymentMethods: [cardPaymentMethod],
       transactionInfo,
       merchantInfo
     }
   };

   googlePayClient
     .loadPaymentData(paymentDataRequest)
     .then(function (paymentData) {
       console.log(paymentData);
     })
     .catch(function (err) {
       console.log(err);
     });
 }


 const processPaymentStrip=()=> {
  const { stripe, elements } = this.props;
  if (!stripe || !elements) {
    return;
  }

  const card = elements.getElement(CardElement);
  const result = stripe.createToken(card);
  if (result.error) {
    console.log(result.error.message);
  } else {
    console.log(result.token);
  }
 }
   useEffect(() => {
      // googlePayClient.isReadyToPay(googlePayBaseConfiguration);
      console.log("aqib")
      if (!!localStorage.userDetails) {            
        setUser(JSON.parse(localStorage.userDetails));
     }
      console.log(localStorage.getItem("user_id"))
      window.addEventListener('resize', () => {
         if (window.innerWidth < 576) setImageShow(true);
         else setImageShow(false);
      });
      return window.removeEventListener('resize', () => {});

   }, []);

   const showButtons = () => {
      setHideCheckout(!HideCheckout);
   };
   const handleClickOpen = () => {
      setOpen(true);
    };
    
    const handleClose = () => {
      setOpen(false);
    };

    const ContinuesForCheckout = () => {
      
      
      !!user?setstepNo(3):setstepNo(2);
      const { from } = { from: { pathname: !!user?"/dream-cart-payment":"/dream-cart-information" } };
      history.push(from)
    };



   return (
      <div className="marginTop-Sm">
         {checkoutAsGuest ? (
            <div className="container-fluid px-0 ">
               <div className="row">
                  <div
                     className="col-6 col-sm-6 col-md-6"
                     // style={{ textAlign: 'center', padding: '0', margin: '0' }}
                  >
                    <Link  to="account/login">
                     <CheckoutBtns
                        text="Sign Up"
                        backgroundColor="#1663BE"
                        color="#FFFFFF"
                        border="1px solid #707070"
                     />
                    </Link>
                  </div>
                  <div className="col-6 col-sm-6 col-md-6">
                     <Link to="account/login">
                     <CheckoutBtns
                        text="Login"
                        backgroundColor="#1663BE"
                        color="#FFFFFF"
                        border="1px solid #707070"
                     />
                     </Link>
                  </div>
                  
                  
               </div>
            </div>
         ) : (
          <Link to={!!user?"/dream-cart-payment":"/dream-cart-information"}>
           <button className={`btn form-control my-1 buttonRound`} style={{border:"1px solid",backgroundColor:"#1663BE",color:"#FFFFFF"}} onClick={ContinuesForCheckout}>
          <img
                   src={imageShow ? CheckoutBilling : CreditCard}
                   alt=""
                   height={24}
                   className="absoluteClass U-paddingLeftText"
                />
                <span className="FloarRight-Responsive">Countinue with card</span>
             </button>
          </Link>
         
            // <CheckoutBtns
            //    img={imageShow ? CheckoutBilling : CreditCard}
            //    text="Countinue for Checkout"
            //    
            //    color="#FFFFFF"
            //    border="1px solid #707070"
            //    toggler={showButtons}
            // />
         )}
         {/* <button className={`btn form-control my-1 buttonRound`} style={{border:"1px solid",backgroundColor:"black"}} onClick={processPayment}>
         <img
                  src={GooglePlay}
                  alt=""
                  height={24}
                  className="absoluteClass U-paddingLeftText"
               />
                                    <span className="FloarRight-Responsive" style={{color:"white",fontWeight:"400"}}>Google Pay</span>
            </button> */}
            <div style={{width:"100px"}}>
              {!!RegisterUser?
                          <GooglePayButton
                          buttonSizeMode="fill"
                          className={`btn1 buttonRound`} 
                          environment="TEST"
                          paymentRequest={{
                            apiVersion: 2,
                            apiVersionMinor: 0,
                              allowedPaymentMethods: [
                                {
                                  type: 'CARD',
                                  parameters: {
                                    allowedCardNetworks: ["VISA", "MASTERCARD"],
                                    allowedAuthMethods: ["PAN_ONLY", "CRYPTOGRAM_3DS"],
                                  },
                                  tokenizationSpecification: {
                                    type: 'PAYMENT_GATEWAY',
                                    parameters: {
                                      "gateway": "stripe",
                                      "stripe:version": "2018-10-31",
                                       "stripe:publishableKey": "pk_test_51J9sJcLWHAHcBPawYJoIvw6bio18W18BpYMKJTupgMkfb5UvZwHdD3YIdoR6moN5QVIX8xW3vRxItrFYpilVorqz00dObeqilS"
                                    },
                                    // parameters: {
                                    //   gateway: "stripe",
                                    //   "stripe:version": "v3",
                                    //   "stripe:publishableKey": "pk_test_51J9sJcLWHAHcBPawYJoIvw6bio18W18BpYMKJTupgMkfb5UvZwHdD3YIdoR6moN5QVIX8xW3vRxItrFYpilVorqz00dObeqilS"
                                    // }
                                  },
                                },
                              ],
                              merchantInfo: {
                                merchantId: 'BCR2DN6TQ7AOBHRW',
                                merchantName: 'Dream Makers',
                              },
                              transactionInfo: {
                                totalPriceStatus: 'FINAL',
                                totalPriceLabel: 'Total',
                                totalPrice: '100.00',
                                currencyCode: 'USD',
                                countryCode: 'US',
                              },
                            }}
                            onLoadPaymentData={paymentRequest => {
                              console.log('load payment data', paymentRequest);
                            }}
              />:null
            }

            </div>
           {!!RegisterUser?
              <button className={`btn form-control my-1 buttonRound`} style={{border:"1px solid"}}>
              <img
                    src={AppleStore}
                    alt=""
                    height={24}
                    className="absoluteClass U-paddingLeftText"
                 />
                 <span className="FloarRight-Responsive">Apple pay</span>
              </button>
           :null}
            {/* <StripeCheckout
              label="Strip"
              amount={!!campain_price?campain_price:""}
              billingAddress
              description="Awesome Product"
              image="https://yourdomain.tld/images/logo.svg"
              locale="auto"
              name="https://dreammakers.ae/"
              stripeKey="pk_test_35p114pH8oNuHX72SmrvsFqh00Azv3ZaIA"
              token={onToken}
              className={`btn form-control my-1 buttonRound`} 
              style={{border:"1px solid",backgroundColor:"none"}}
              zipCode
              /> */}
            {/* <button className={`btn form-control my-1 buttonRound`} style={{border:"1px solid"}} onClick={handleClickOpen}>
               <img
                  src={Stripe}
                  alt=""
                  height={24}
                  className="absoluteClass U-paddingLeftText"
               />
               <span className="FloarRight-Responsive">Stripe</span>
            </button> */}
      </div>
   );
};

export default CardBottom;
